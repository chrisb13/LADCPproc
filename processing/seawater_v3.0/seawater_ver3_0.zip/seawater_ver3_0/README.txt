% README file  $Revision: 1.1 $  $Date: 2003/12/12 04:23:22 $
%
%    SEAWATER is a toolkit of MATLAB routines for calculating the
%    properties of sea water. They are a self contained library and
%    are extremely easy to use.  
%
% See the file sw_info.m for info on installation and usage

